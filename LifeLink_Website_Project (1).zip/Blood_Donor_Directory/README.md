# LifeLink — Blood Donor Directory

A beginner-friendly, front-end web application prototype for an AI-Assisted Web Application Project. It is built with HTML, CSS, and vanilla JavaScript, so no package installation or build process is required.

## Features
- Responsive layout for desktop and mobile
- Search demo donor profiles by blood group and city
- Reset search filters
- Add a demo donor profile through a form
- Store new demo entries in this browser using `localStorage`
- Empty-results message when no profile matches
- Clear disclaimer that all provided profiles are fictional

## Run in VS Code
1. Extract `Blood_Donor_Directory.zip`.
2. Open VS Code.
3. Select **File → Open Folder** and choose the extracted `Blood_Donor_Directory` folder.
4. Open `index.html`.
5. If you have the **Live Server** extension, right-click `index.html` and choose **Open with Live Server**. Otherwise, double-click `index.html` in File Explorer to open it in your browser.
6. Test the blood-group filter, location filter, Reset button, and registration form.

## Publish a website link using GitHub Pages
1. Create or sign in to a GitHub account.
2. Create a new public repository, for example `lifelink-blood-donor-directory`.
3. Upload `index.html`, `style.css`, and `script.js` to the repository's root. You may also upload the report and prompt book.
4. In the repository, open **Settings → Pages**.
5. Under the build/deployment source, select **Deploy from a branch**, choose `main` and `/(root)`, then save.
6. Wait for the deployment to finish. GitHub Pages will show your published URL in the Pages section. Open it and test the site.
7. Submit that actual published URL in your college Google Form.

The published URL will be created by GitHub after deployment; it cannot be known in advance. Do not submit a made-up URL.

## Important limitations
This is a classroom prototype, not a live donor network. It has no backend, login, identity verification, medical eligibility checks, or server database. Registration entries are stored only in the browser where they are added. Use fictional information for demonstrations. A real service would require consent, privacy and security controls, and coordination with authorized blood banks.
