# AI-Assisted Web Application Project Report
## LifeLink — Blood Donor Directory

**Student Name:** [Enter your full name]  
**Division:** [Enter division]  
**GR Number:** [Enter GR number]  
**Project Topic:** Blood Donor Directory  
**Published Website Link:** [Paste your actual deployed link here]

## 1. Introduction
LifeLink is a simple web application prototype designed to demonstrate how a directory could help users search for potential blood donors using blood group and city. The project uses prompt engineering and AI-assisted development to plan, generate, improve, and test a front-end interface.

## 2. Problem Statement
During a time-sensitive need, people may find it difficult to organize donor information by blood group and location. A searchable directory concept can make relevant listings easier to browse. This prototype uses fictional data only and is not intended for real medical use.

## 3. Objective
- Build a simple, responsive web application prototype.
- Search sample donor listings by blood group and city.
- Demonstrate a registration form interaction.
- Use AI prompts to plan and improve the design and functionality.
- Test important interactions and document improvements.

## 4. Target Users
The intended users of a future real service could include people looking for donor information, voluntary donors, and authorized organizations. In this classroom prototype, users can only interact with fictional demo profiles.

## 5. Tools and Technologies
- Visual Studio Code
- HTML for structure
- CSS for design and responsive layout
- JavaScript for search, filtering, and demo registration
- AI assistant for planning, prompt development, code generation, and review
- GitHub Pages (optional) for publishing the static website

## 6. Main Features
1. Landing page with project introduction.
2. Blood group and location search.
3. Donor result cards.
4. Reset search filters.
5. Demo registration form.
6. Local-browser storage for added demo profiles.
7. Mobile-friendly layout and privacy disclaimer.

## 7. Prompt Engineering Process
The prompt book documents the prompts used to plan the interface, generate the first version, improve the design, test and fix functionality, and add privacy notices. Prompts were made more specific when requirements such as empty states, safe rendering, and responsive design needed attention.

## 8. Testing
| Test | Expected result | Result |
|---|---|---|
| Open the website | Home page and demo profiles appear | [Pass/Fail] |
| Search by blood group | Only matching blood groups appear | [Pass/Fail] |
| Search by city | Profiles for matching city appear | [Pass/Fail] |
| Combine filters | Both conditions are applied | [Pass/Fail] |
| Reset filters | Full directory returns | [Pass/Fail] |
| Search with no match | Helpful empty-state message appears | [Pass/Fail] |
| Add a demo profile | Profile appears in the current browser | [Pass/Fail] |
| Mobile screen | Content fits a narrow screen | [Pass/Fail] |

## 9. Limitations and Safety
This prototype does not have a backend or shared database. Registration entries are stored in local storage on the current browser only. Donor identity, consent, medical eligibility, and availability are not verified. All included profiles are fictional. A real implementation would require secure data handling, explicit consent, verification, and appropriate coordination with authorized blood banks.

## 10. Conclusion
LifeLink demonstrates how prompt engineering and AI-assisted tools can support the planning and creation of a simple web application. The project includes functional search and demo registration, a responsive interface, and a documented testing process. It also highlights the importance of verifying AI-generated output and considering privacy and safety before a prototype is used in the real world.

## 11. Evidence to Attach
Add screenshots of:
1. Home page.
2. Search filters.
3. Search results after filtering.
4. No-results message.
5. Demo registration form.
6. Successful demo profile addition.
7. Mobile layout (optional).
8. Published website opened in a browser.

## Before submission
Replace all bracketed placeholders, test the published website, add screenshots, and export this report as a PDF. Name the PDF exactly as instructed by your college, for example `3EN1_123456_Rahul.pdf`. Use your own division, GR number, and name; do not copy the example values.
