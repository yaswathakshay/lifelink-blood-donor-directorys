# Prompt Book — LifeLink Blood Donor Directory

## Prompt 1: Plan the application
**Prompt used:**  
"Act as a UI/UX designer. Plan a beginner-friendly Blood Donor Directory web application named LifeLink. It should help users search fictional donor listings by blood group and city. List the target users, problem statement, objective, core features, page sections, accessibility needs, and privacy limitations. Keep the prototype simple enough for HTML, CSS, and JavaScript."

**Purpose:** Establish the problem, users, scope, and basic requirements.

## Prompt 2: Generate the first version
**Prompt used:**  
"Create a responsive front-end prototype called LifeLink using only HTML, CSS, and vanilla JavaScript. Include a welcome hero section, a search form with blood group and city filters, fictional donor cards, a how-it-works section, and a demo registration form. Use a clean healthcare-inspired design. Make the filters functional and show an empty state when there are no results. Clearly label sample donor information as fictional."

**Purpose:** Generate the core user interface and interactions.

## Prompt 3: Improve the design
**Prompt used:**  
"Improve the visual design of the Blood Donor Directory. Use consistent spacing, readable typography, accessible form labels, responsive cards, clear call-to-action buttons, and a mobile-friendly layout. Avoid overcrowding and ensure navigation links scroll to the correct sections."

**Purpose:** Improve usability, layout, and responsiveness.

## Prompt 4: Fix and test functionality
**Prompt used:**  
"Review the search and registration JavaScript. Make blood group matching case-insensitive, make city matching partial and case-insensitive, ensure the Reset button clears all filters, prevent blank registrations, safely render user-entered names as text rather than HTML, and show a helpful message when no results match."

**Purpose:** Improve reliability and safe rendering of user-entered content.

## Prompt 5: Add privacy safeguards
**Prompt used:**  
"Add a clear notice explaining that all donor profiles are fictional demo records, registration data stays in local browser storage, and the prototype does not verify eligibility or availability. Do not add real personal contact details. Explain what a production system would need before use."

**Purpose:** Make the prototype's limits clear and reduce privacy risks.

## Testing record
- Tested the initial page load and display of fictional donor profiles.
- Tested searching by blood group only.
- Tested searching by city only.
- Tested combined blood group and city filters.
- Tested Reset after a search.
- Tested an unmatched search and checked the empty-state message.
- Tested adding a fictional profile and confirmed it appeared in results.
- Tested the layout at desktop and mobile widths.
- Confirmed that the page explains this is not a real donor service.

## Reflection / improvement
AI-assisted development made it faster to plan a layout and create an initial prototype. Testing remains important because generated code can have defects. The next improvement would be a secure backend, consent-based registration, verified information, accessibility review, and coordination with authorized blood banks.
